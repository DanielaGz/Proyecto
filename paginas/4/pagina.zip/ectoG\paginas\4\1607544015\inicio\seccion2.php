<div class="container"><!-- Video -->
    <div class="card m-3 shadow-lg " style="border-radius: 4vmax; align-items: center;">
        <div class="embed-responsive embed-responsive-16by9 m-5" style="width: 90%;">
            <!-- Url --><iframe class="embed-responsive-item" src="https://www.youtube.com/embed/TYrcdhots80" allowfullscreen style="border-radius: 1vmax;"></iframe>
        </div>
    </div>
</div>