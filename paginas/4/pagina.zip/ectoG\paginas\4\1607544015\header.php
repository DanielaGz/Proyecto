<div class="encabezado text-white">
<!-- alinear --><div class='container d-flex justify-content-end'>
        <div class="caja">
            <a href="index.php?pid=<?php
                                    echo base64_encode("inicio/inicio.php");
                                    ?>">
                <br>
                <img src="img/logo.png" width="90vh"></a>
            <!-- Titulo --><h4><strong>Titulo</strong></h4>
           <br> 
        </div>
    </div>
</div>