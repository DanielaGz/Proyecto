<nav class="navbar navbar-dark navbar-expand-lg sticky-top">
    <a class="navbar-brand" href="#">Menu</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav mr-auto">
	<!-- Seccion1 --><li class='nav-item'><a class='nav-link' href='#Seccion1'>Seccion1</a></li>
	<!-- Seccion2 --><li class='nav-item'><a class='nav-link' href='#Seccion2'>Seccion2</a></li>
	<!-- Seccion3 --><li class='nav-item'><a class='nav-link' href='#Seccion3'>Seccion3</a></li>
	<!-- nuevo -->
        </ul>
        <span class="navbar-text">
            <!-- Texto Barra -->
        </span>
    </div>
</nav>