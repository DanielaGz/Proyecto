<div class="card"> <!-- Texto -->
    <div class="card-header a" style="font-size: 3vmax;">
		<!-- Titulo -->sadasds
    </div>
    <div class="card-body">
        <p class="card-text" style="font-size: 2vmax;">
		<!-- Contenido -->ujljmlkjl
        </p>
    </div>
</div>