<div class="">
	<!-- Seccion1 --><div id='Seccion1' class='selec'><?php include 'seccion1.php' ?></div>
	<!-- Seccion2 --><div id='Seccion2' class='selec'><?php include 'seccion2.php' ?></div>
	<!-- Seccion3 --><div id='Seccion3' class='selec'><div class='seleccionado'></div><?php include 'seccion3.php' ?></div>
	<!-- Nueva -->
</div>