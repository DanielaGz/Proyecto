<div class="card"> <!-- Texto -->
    <div class="card-header a" style="font-size: 3vmax;">
        <!-- Titulo -->Titulo
    </div>
    <div class="card-body">
        <p class="card-text" style="font-size: 2vmax;">
            <!-- Contenido -->Texto
        </p>
    </div>
</div>